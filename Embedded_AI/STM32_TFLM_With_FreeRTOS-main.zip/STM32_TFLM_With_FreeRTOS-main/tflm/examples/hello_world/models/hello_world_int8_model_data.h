#include <cstdint>

constexpr unsigned int g_hello_world_int8_model_data_size = 2704;
extern const unsigned char g_hello_world_int8_model_data[];
